package com.prabeen.employee.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prabeen.employee.entity.CalclationTax;
import com.prabeen.employee.entity.EmployeeEntity;
import com.prabeen.employee.entity.TaxEntity;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	private final static Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	private List<EmployeeEntity> employees = new ArrayList<>();

	@PostMapping("/employees")
	public ResponseEntity<String> addEmployee(@Valid @RequestBody EmployeeEntity employee) {
		employees.add(employee);
		logger.info("employee"+employee);
		return ResponseEntity.status(HttpStatus.CREATED).body("Employee added successfully");
	}

	@GetMapping("/tax_deduction")
	public List<TaxEntity> getTaxDeductions() {
		List<TaxEntity> taxResponses = new ArrayList<>();

		for (EmployeeEntity employee : employees) {
			double yearlySalary = employee.getSalary() * 12;
			double taxAmount = CalclationTax.calculateTax(yearlySalary);
			double cessAmount = CalclationTax.calculateCess(taxAmount);

			TaxEntity taxResponse = new TaxEntity();
			taxResponse.setEmployeeCode(employee.getEmployeeId());
			taxResponse.setFirstName(employee.getFirstName());
			taxResponse.setLastName(employee.getLastName());
			taxResponse.setYearlySalary(yearlySalary);
			taxResponse.setTaxAmount(taxAmount);
			taxResponse.setCessAmount(cessAmount);

			taxResponses.add(taxResponse);
			logger.info("TaxResponse"+taxResponse);
		}

		return taxResponses;

	}
	}
