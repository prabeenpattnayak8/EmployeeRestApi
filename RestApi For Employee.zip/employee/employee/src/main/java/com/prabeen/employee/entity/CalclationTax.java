package com.prabeen.employee.entity;

public class CalclationTax {

	public static double calculateTax(double yearlySalary) {
		if (yearlySalary <= 250000) {
			return 0;
		} else if (yearlySalary <= 500000) {
			return 0.05 * (yearlySalary - 250000);
		} else if (yearlySalary <= 1000000) {
			return 0.05 * 250000 + 0.1 * (yearlySalary - 500000);
		} else {
			return 0.05 * 250000 + 0.1 * 500000 + 0.2 * (yearlySalary - 1000000);
		}
	}

	public static double calculateCess(double taxAmount) {
		return 0.04 * taxAmount;
	}

}
